var g2_isOpen = true;

var gameTwoScreen = function(game){}
gameTwoScreen.prototype = {}
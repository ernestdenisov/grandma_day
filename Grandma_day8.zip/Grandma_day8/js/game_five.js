var g5_isOpen = true;

var gameFiveScreen = function(game){}
gameFiveScreen.prototype = {}
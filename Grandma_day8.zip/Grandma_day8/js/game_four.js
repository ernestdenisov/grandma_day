var g4_isOpen = true;

var gameFourScreen = function(game){}
gameFourScreen.prototype = {}
var g1_dot1, g1_dot2, g1_dot3, g1_dot4, g1_dot5, g1_dot6;
var g1_line1, g1_line2, g1_line3, g1_line4, g1_line5;
var g1_base1, g1_base2, g1_base3, g1_base4, g1_base5, g1_base6;
var g1_colors;
var g1_dots;
var g1_lines;
var g1_dotsPositions;
var g1_basesPositions;
var g1_bases;
var g1_radius = 30;
//var game = new Phaser.Game(640, 480, Phaser.AUTO, null, {create: create, update: update, render: render}, false);
var g1_text1, g1_text2, g1_text3, g1_text4, g1_text5, g1_text6;
var g1_texts;
var g1_style;
var g1_base1Counter, g1_base2Counter, g1_base3Counter, g1_base4Counter, g1_base5Counter, g1_base6Counter;
var g1_baseCounters;
var g1_isOpen = true;

function toTitle(){
		game.state.start("TitelScreen");
	}

function dotsBasesCollision(){
	//console.log("dotsBasesCollision");
	for(var i = 0; i < g1_dots.length; i++){
		if(Math.sqrt(((g1_dots[i].x - g1_bases[i].x) * (g1_dots[i].x - g1_bases[i].x)) + ((g1_dots[i].y - g1_bases[i].y) * 
			(g1_dots[i].y - g1_bases[i].y))) < 10){
			g1_dots[i].x = g1_bases[i].x;
			g1_dots[i].y = g1_bases[i].y;
			g1_dots[i].input.disableDrag();
			g1_dots[i].scale.x = 0;
			g1_dots[i].scale.y = 0;
			g1_baseCounters[i]++;
			g1_texts[i].setText('base' + (i + 1) + ": " + g1_baseCounters[i]);
			g1_baseCounters[i] = null;
		}
	}
}

var gameOneScreen = function(game){}
gameOneScreen.prototype = {
	create: function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.stage.backgroundColor = '#FFE0B2';	
		g1_colors = [0x26C6DA, 0x00E676, 0x3F51B5, 0xFDD835, 0xFF3D00, 0x1DE9B6, 0xF57C00];
		g1_dots = [g1_dot1, g1_dot2, g1_dot3, g1_dot4, g1_dot5, g1_dot6];
		g1_bases = [g1_base1, g1_base2, g1_base3, g1_base4, g1_base5, g1_base6];
		g1_lines = [g1_line1, g1_line2, g1_line3, g1_line4, g1_line5];
		g1_texts = [g1_text1, g1_text2, g1_text3, g1_text4, g1_text5, g1_text6];
		g1_baseCounters = [g1_base1Counter, g1_base2Counter, g1_base3Counter, g1_base4Counter, g1_base5Counter, g1_base6Counter];
		g1_dotsPositions = [{x: 200, y: 100},{x: 200, y: 250},{x: 300, y: 200},
											{x: 300, y: 350},{x: 400, y: 250},{x: 400, y: 350}];
		g1_basesPositions = [{x: 200, y: 450},{x: 250, y: 450},{x: 300, y: 450},
											{x: 350, y: 450},{x: 400, y: 450},{x: 450, y: 450}];
		
		for(var i = 0; i < g1_lines.length; i++){
			g1_lines[i] =  game.add.graphics(0,0);
			g1_lines[i].moveTo(g1_dotsPositions[i].x, g1_dotsPositions[i].y)
			g1_lines[i].lineTo(g1_dotsPositions[i+1].x, g1_dotsPositions[i+1].y);	
			g1_lines[i].lineStyle(g1_radius, g1_colors[6], 1);
		}
		for(var i = 0; i < 3; i++){
			//console.log(dotsPositions[i].x);
			//var ln = lines[i];
			g1_dots[2*i] = game.add.graphics(g1_dotsPositions[2*i].x, g1_dotsPositions[2*i].y);
			g1_dots[2*i].beginFill(g1_colors[2*i], 1);
			g1_dots[2*i].drawCircle(0, 0, g1_radius);	
			g1_dots[2*i].inputEnabled = true;
			g1_dots[2*i].input.enableDrag(false, false, false, 255, null, null);
			g1_dots[2*i].clr = g1_colors[2*i];
			
			g1_dots[2*i+1] = game.add.graphics(g1_dotsPositions[2*i + 1].x, g1_dotsPositions[2*i + 1].y);
			g1_dots[2*i+1].beginFill(g1_colors[2*i+1], 1);
			g1_dots[2*i+1].drawCircle(0, 0, g1_radius);	
			g1_dots[2*i+1].inputEnabled = true;
			g1_dots[2*i+1].input.enableDrag(false, false, false, 255, null, null);
			g1_dots[2*i+1].clr = g1_colors[2*i+1];
		}
		
		for(var i = 0; i < g1_dots.length; i++){
			g1_bases[i] = game.add.graphics(g1_basesPositions[i].x, g1_basesPositions[i].y);
			g1_bases[i].beginFill(g1_colors[i], 1);
			g1_bases[i].drawCircle(0, 0, g1_radius);
			g1_bases[i].inputEnabled = true;
			g1_bases[i].clr = g1_colors[i];
			g1_baseCounters[i] = 0;
		}
			
		game.physics.enable(g1_dots, Phaser.Physics.ARCADE);
		game.physics.enable(g1_bases, Phaser.Physics.ARCADE);
		
		g1_style = { font: "14px Arial", fill: "#ffffff", align: "center" }
		
		for(var i = 0; i < g1_bases.length; i++){
			g1_texts[i] = game.add.text(game.width - 100, 10 + 17*i, 'base' + (i + 1) + ": " + g1_baseCounters[i], g1_style);
			g1_texts[i].setShadow(1, 1, 'rgba(0,0,0,1.0)', 2);
			g1_texts[i].padding.x = 5;
		}

			titleBtn = game.add.button(50, 50,
				"icons", toTitle, this);
			titleBtn.frame = 15;
			titleBtn.anchor.set(0.5);
			titleBtn.scale.setTo(0.5, 0.5);
	},
	update: function(){
		for(var i = 0; i < g1_lines.length; i++){
			g1_lines[i].clear();
			g1_lines[i].lineStyle(g1_radius, g1_colors[6], 1);
		
			g1_lines[i].moveTo(g1_dots[i].x, g1_dots[i].y)
			g1_lines[i].lineTo(g1_dots[i+1].x, g1_dots[i+1].y);		
		}
		for(var i = 0; i < g1_dots.length; i++){
			//console.log(dots[i].clr);
		}
		
		game.physics.arcade.collide(g1_dots, g1_bases, dotsBasesCollision);
		},
}



// function create(){
// 	//var circle = new Phaser.Circle(20,20,20);
	
// }
// function update(){
	
// }
	

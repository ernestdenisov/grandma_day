var g3_isOpen = true;

var gameThreeScreen = function(game){}
gameThreeScreen.prototype = {}
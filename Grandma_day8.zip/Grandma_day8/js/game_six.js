var g6_isOpen = true;

var gameSixScreen = function(game){}
gameSixScreen.prototype = {}
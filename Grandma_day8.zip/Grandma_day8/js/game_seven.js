var g7_isOpen = true;

var gameSevenScreen = function(game){}
gameSevenScreen.prototype = {}
var game = new Phaser.Game(1024, 768, Phaser.AUTO);

window.onload = function(){

	var biglogo = null;
	var icons = null;
	var sky = null;
	var clouds = null;
	var grass = null;
	var grandmaImg_titleScreen = null;
	var grandmaImg_titleScreen_r_h = null;
	var grandmaImg_titleScreen_l_h = null;
	var settingsBtn, levelsBtn, achivementBtn, gameOneBtn;
	var currentRightHandAngle = 0;
	var isOpenLevels;

	var preloadScreen = function(game){}
	preloadScreen.prototype = {
		init: function () {
	    this.game.renderer.renderSession.roundPixels = true;
	    this.physics.startSystem(Phaser.Physics.ARCADE);
	    this.physics.arcade.gravity.y = 800;
  	},
		preload: function(){
			game.load.image('biglogo', 'assets/images/ernygameslogo.png');
			game.load.spritesheet('icons', 'assets/images/icons_wide_w_innershadow.png', 128, 128);
			game.load.image('sky', 'assets/images/sky.png');
	    game.load.image('cloud1', 'assets/images/cloud_long1.png');
	    game.load.image('cloud2', 'assets/images/cloud_long2.png');
	    game.load.image('cloud3', 'assets/images/cloud_long3.png');
	    game.load.image('cloud4', 'assets/images/cloud_long4.png');
	    game.load.image('cloud5', 'assets/images/cloud_long5.png');
	    game.load.image('grandmaImg_titleScreen', 'assets/images/grandmother_placeholder1_base.png');
	    game.load.image('grandmaImg_titleScreen_r_h', 'assets/images/grandmother_placeholder1_right_hand.png');
	    game.load.image('grandmaImg_titleScreen_l_h', 'assets/images/grandmother_placeholder1_left_hand.png');
	    game.load.image('cir_play', 'assets/images/play_opacity10.png');
	    game.load.image('locked_level', 'assets/images/locked1.png');
	    game.load.image('unlocked_level', 'assets/images/unlocked1.png');


		},
		create: function(){
			game.stage.backgroundColor = 0x7B519D;
			game.add.text(0, 0, "PreloadScreen");
			biglogo = game.add.image(game.world.centerX, game.world.centerY, 'biglogo')
			biglogo.anchor.set(0.5);
			biglogo.scale.setTo(0.5, 0.5);
			fadePicture(biglogo)
			isOpenLevels = [window.g1_isOpen, window.g2_isOpen, window.g3_isOpen, window.g4_isOpen, 
											window.g5_isOpen, window.g6_isOpen, window.g7_isOpen, window.g8_isOpen];
		},
	}

	function toTitle(){
		game.state.start("TitelScreen");
	}
	function toSettings(){
		game.state.start("SettingsScreen");
	}
	function toMenu(){
		game.state.start("MenuScreen");
	}
	function toAchieve(){
		game.state.start("AchievementScreen");
	}

	function toGameOne(){
		game.state.start("GameOneScreen");
	}
	function toGameTwo(){
		game.state.start("GameTwoScreen");
	}
	function toGameThree(){
		game.state.start("GameThreeScreen");
	}
	function toGameFour(){
		game.state.start("GameFourScreen");
	}
	function toGameFive(){
		game.state.start("GameFiveScreen");
	}
	function toGameSix(){
		game.state.start("GameSixScreen");
	}
	function toGameSeven(){
		game.state.start("GameSevenScreen");
	}
	function toGameEight(){
		game.state.start("GameEightScreen");
	}

	function showPicture(biglogo) {
    game.add.tween(biglogo).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true);
	}
	function fadePicture(biglogo) {
    game.add.tween(biglogo).to( { alpha: 0 }, 2000, Phaser.Easing.Linear.None, true);
    game.time.events.add(Phaser.Timer.SECOND * 3, toTitle, this);
	}

	function createText(y, txt, align, padding, font, size, fill) {

    var text = game.add.text(game.world.centerX, y, txt);
    text.anchor.set(0.5);
    text.align = align || 'center';
    text.padding.x = padding || 0;

    //  Font style
    text.font = font || 'Arial';
    text.fontSize = size || 100;
    text.fill = fill || '#ffffff';

    return text;
	}

	function moveRightHand(){
		if(grandmaImg_titleScreen_r_h.angle > 45){
			grandmaImg_titleScreen_r_h.angle -= 1;
		}
		if(grandmaImg_titleScreen_r_h.angle < -45){
			grandmaImg_titleScreen_r_h.angle -= 1;
		}
	}

	var titelScreen = function(game){}

	titelScreen.prototype = {

		create: function(){
			sky = game.add.tileSprite(0, 0, game.width, game.height, 'sky');
   		sky.scale.setTo(1, 1);

   		for (var i = 0; i < 10; i++) {
   			grass = game.add.graphics(600*i, game.height+500);
				grass.beginFill(0x00E676, 1);
				grass.drawCircle(0, 0, 1500);
   		}

   		clouds = game.add.physicsGroup();
	    clouds.create(-150, 50, 'cloud1');
	    clouds.create(game.width*0.25-75, 250, 'cloud2');
	    clouds.create(game.width*0.5, 100, 'cloud3');
	    clouds.create(game.width*0.75+75, 420, 'cloud4');
	    clouds.create(game.width+150, 300, 'cloud5');

	    clouds.setAll('body.allowGravity', false);
	    clouds.setAll('body.immovable', true);
	    clouds.setAll('body.velocity.x', -50);
	    clouds.setAll('alpha', 0.6);
	    clouds.setAll('anchor.x', 0.5);
	    clouds.setAll('anchor.y', 0.5);
	    clouds.scale.set(1, 1);

	    //grandma titleScreen animation

	    grandmaImg_titleScreen = game.add.sprite(257/2, game.height-340/2, 'grandmaImg_titleScreen');
	    grandmaImg_titleScreen.anchor.set(0.5);
	    grandmaImg_titleScreen.scale.set(0.5, 0.5);

	    grandmaImg_titleScreen_r_h = game.add.sprite((257/2)-40, (game.height-340/2)+10, 'grandmaImg_titleScreen_r_h');
	    grandmaImg_titleScreen_r_h.anchor.set(0.5, 0);
	    grandmaImg_titleScreen_r_h.scale.set(0.5, 0.5);
	    grandmaImg_titleScreen_r_h.rotateDirection = 1;

	    grandmaImg_titleScreen_l_h = game.add.sprite((257/2)+80, (game.height-340/2)+25, 'grandmaImg_titleScreen_l_h');
	    grandmaImg_titleScreen_l_h.anchor.set(1, 0);
	    grandmaImg_titleScreen_l_h.scale.set(0.5, 0.5);
	    grandmaImg_titleScreen_l_h.rotateDirection = 0;

	    var style = {
				font: "52px Monospace",
				fill: "#00ff00",
				align: "center"
			}
			//game.add.text(0, 0, "TitelScreen");
			//gameNameTxt = game.add.text(game.width/2, game.height/2, "Grandpa Day", style).anchor.set(0.5);
			//gameNameTxt.setShadow(5, 5, 'rgba(0,0,0,0.5)', 15);

			text = createText((game.height/2)-100, 'Grandma Day', 'center', 10, 'Righteous', 120, '#FF8A65');
    	text.setShadow(5, 5, 'rgba(0,0,0,0.5)', 0);
    	text.scale.set(1, 1);

			settingsBtn = game.add.button(game.width - 50, 50, "icons", toSettings, this);
			settingsBtn.frame = 10;
			settingsBtn.anchor.set(0.5);
			settingsBtn.scale.setTo(0.5, 0.5);

			menuBtn = game.add.button(game.width/2, game.height/2 + 100, "cir_play", toMenu, this);
			//menuBtn.frame = 6;
			menuBtn.anchor.set(0.5);
			menuBtn.scale.setTo(0.5, 0.5);
			//menuBtn.tint = 0xffffff;

			achivementBtn = game.add.button(game.width - 128, 50,	"icons", toAchieve, this);
			achivementBtn.frame = 12;
			achivementBtn.anchor.set(0.5);
			achivementBtn.scale.setTo(0.5, 0.5);
	
		},
		update: function(){
			clouds.forEach(this.returnClouds,this);
			
			currentRightHandAngle = grandmaImg_titleScreen_r_h.angle;

			if(grandmaImg_titleScreen_r_h.rotateDirection === 1){
				grandmaImg_titleScreen_r_h.angle -= 0.3;
				if(grandmaImg_titleScreen_r_h.angle <= -10){
					grandmaImg_titleScreen_r_h.rotateDirection = 0;
				}
			}else{
				grandmaImg_titleScreen_r_h.angle += 0.3;
				if (grandmaImg_titleScreen_r_h.angle >= 10) {
					grandmaImg_titleScreen_r_h.rotateDirection = 1;
				}
			}


			if(grandmaImg_titleScreen_l_h.rotateDirection === 1){
				grandmaImg_titleScreen_l_h.angle -= 0.3;
				if(grandmaImg_titleScreen_l_h.angle <= -10){
					grandmaImg_titleScreen_l_h.rotateDirection = 0;
				}
			}else{
				grandmaImg_titleScreen_l_h.angle += 0.3;
				if (grandmaImg_titleScreen_l_h.angle >= 10) {
					grandmaImg_titleScreen_l_h.rotateDirection = 1;
				}
			}
			
			
		},
		returnClouds: function(cloud){
	    if(cloud.x < -cloud.width){
	      cloud.x = game.width + cloud.width;
	      //cloud.y = Math.floor(Math.random() * 400);
	    }
  	},
		
	}

	var menuScreen = function(game){}
	menuScreen.prototype = {
		create: function(){
			game.stage.backgroundColor = 0x90CAF9;
			game.add.text(0, 0, "MenuScreen");

			titleBtn = game.add.button(50, 50,
				"icons", toTitle, this);
			titleBtn.frame = 15;
			titleBtn.anchor.set(0.5);
			titleBtn.scale.setTo(0.5, 0.5);

			gameOneBtn = game.add.button((game.width/2) - 300, (game.height/2) - 100,	"unlocked_level", toGameOne, this);
			gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) - 100, (game.height/2) - 100,	"locked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);
			// gameOneBtn.alpha = 0.5;

			// gameOneBtn = game.add.button((game.width/2) + 100, (game.height/2) - 100,	"unlocked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) + 300, (game.height/2) - 100,	"locked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) - 300, (game.height/2) + 100,	"unlocked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) - 100, (game.height/2) + 100,	"locked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) + 100, (game.height/2) + 100,	"unlocked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);

			// gameOneBtn = game.add.button((game.width/2) + 300, (game.height/2) + 100,	"locked_level", toGameOne, this);
			// gameOneBtn.anchor.set(0.5);



		},
		update: function(){

		},
		
	}

	var settingsScreen = function(game){}
	settingsScreen.prototype = {
		create: function(){
			game.add.text(0, 0, "SettingsScreen");

			game.add.text(100, 0, "font: https://www.iconfinder.com/Kh.Artyom");
			game.add.text(100, 20, "images: https://pixabay.com/ru/users/OpenClipart-Vectors-30363/");

			titleBtn = game.add.button(50, 50,
				"icons", toTitle, this);
			titleBtn.frame = 15;
			titleBtn.anchor.set(0.5);
			titleBtn.scale.setTo(0.5, 0.5);
		},
	}

	var achievementScreen = function(game){}
	achievementScreen.prototype = {
		create: function(){
			game.add.text(0, 0, "achievementScreen");

			titleBtn = game.add.button(50, 50,
				"icons", toTitle, this);
			titleBtn.frame = 15;
			titleBtn.anchor.set(0.5);
			titleBtn.scale.setTo(0.5, 0.5);
		},
	}

	var gameOver = function(game){}
	gameOver.prototype = {
		create: function(){
			game.add.text(0, 0, "GameOver");
		},
	}

	game.state.add("PreloadScreen", preloadScreen);
	game.state.add("TitelScreen", titelScreen);
	game.state.add("MenuScreen", menuScreen);
	game.state.add("SettingsScreen", settingsScreen);
	game.state.add("GameOver", gameOver);
	game.state.add("AchievementScreen", achievementScreen);
	game.state.add("GameOneScreen", gameOneScreen);
	game.state.add("GameTwoScreen", gameTwoScreen);
	game.state.add("GameThreeScreen", gameThreeScreen);
	game.state.add("GameFourScreen", gameFourScreen);
	game.state.add("GameFiveScreen", gameFiveScreen);
	game.state.add("GameSixScreen", gameSixScreen);
	game.state.add("GameSevenScreen", gameSevenScreen);
	game.state.add("GameEightScreen", gameEightScreen);

	game.state.start("PreloadScreen");
}
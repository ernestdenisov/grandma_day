var g8_isOpen = false;

var gameEightScreen = function(game){}
gameEightScreen.prototype = {}